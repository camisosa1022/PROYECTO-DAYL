import math
def ceil(value):
    return int(math.ceil(value))