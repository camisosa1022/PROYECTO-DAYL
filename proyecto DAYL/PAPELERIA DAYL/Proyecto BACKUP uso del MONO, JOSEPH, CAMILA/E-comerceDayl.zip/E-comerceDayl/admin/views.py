from django.shortcuts import render, redirect
from .decorators import only_admin_access
from producto.models import *
from django.http import JsonResponse
from django.core import serializers
from .forms import ProductoForm,ColorForm
# Create your views here.

@only_admin_access
def index(request):
    return render(request,'admin/index.html',{'url':'inicio'})
@only_admin_access
def producto(request):
    productos = Producto.objects.all()
    subcategorias = Subcategoria.objects.all()
    proveedores = Proveedor.objects.all()
    print(proveedores)
    url = 'producto'
    context = {'productos': productos,
               'url':url,
               'subcategorias':subcategorias,
               'proveedores':proveedores}
    return render(request,'admin/producto.html',context)
@only_admin_access
def producto_edit(request):
    producto_id = request.GET.get('producto_id')
    try:
        producto = Producto.objects.get(id=producto_id)
        producto_json = serializers.serialize('json', [producto])
        return JsonResponse({'producto': producto_json,'id_producto':producto_id})
    except Color.DoesNotExist:
        return JsonResponse({'error': 'Producto no encontrado'})
    pass
@only_admin_access
def editar_producto(request,id_producto):    
    try:
        producto = Producto.objects.get(id=id_producto)
    except:
        return redirect('admin:index')
    form = ProductoForm(request.POST,instance=producto)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('admin:producto')
    return redirect('admin:index')

@only_admin_access
def producto_registro(request):
    form = ProductoForm(request.POST)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('admin:producto')
    return redirect('admin:index')

@only_admin_access
def color(request):
    context = {
        'form':ColorForm(request.POST),
        'productos':Producto.objects.all(),
        'colores': Color.objects.all(),
        'url':'color', 
    }
    return render(request,'admin/color.html',context)
@only_admin_access
def color_registro(request):
    form = ColorForm(request.POST, request.FILES)
    if request.method == "POST":
        if form.is_valid():
            print(form.cleaned_data['imagen'])
            form.save()
            return redirect('admin:color')
    return redirect('admin:index')
    
@only_admin_access
def editar_color(request,id_color):
    try:
        color = Color.objects.get(id=id_color)
    except:
        return redirect('admin:index')
    form = ProductoForm(request.POST,request.FILES,instance=color)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('admin:color')
    return redirect('admin:index')

@only_admin_access
def color_edit(request):
    color_id = request.GET.get('id_color')
    try:
        color = Color.objects.get(id=color_id)
        color_json = serializers.serialize('json', [color])
        return JsonResponse({'color': color_json,'id_color':color_id})
    except Color.DoesNotExist:
        return JsonResponse({'error': 'color no encontrado'})
    pass