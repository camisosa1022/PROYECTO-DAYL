from django.urls import path, include
from . import views
from django.conf import settings
from django.conf.urls.static import static
from buycar.views import *

app_name = 'admin'
urlpatterns = [
    path('', views.index, name="index"),
    path('producto/',views.producto, name="producto"),
    path('producto/registro', views.producto_registro, name="producto_registro"),
    path('producto/edit/', views.producto_edit, name="producto_edit"),
    path('producto/edit/<int:id_producto>', views.editar_producto, name="editar_producto"),
    path('color/',views.color, name='color'),
    path('color/registro', views.color_registro, name="color_registro"),
    path('color/edit/', views.color_edit, name="color_edit"),
    path('color/edit/<int:id_color>', views.editar_color, name="editar_color"),
    ]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)