function cambiarDiseno() {
    const anchoPantalla = window.innerWidth;
    const bodyElement = document.querySelector('body');
  
    if (anchoPantalla > 767) {
      bodyElement.classList.add('pantalla-grande');
      bodyElement.classList.remove('pantalla-pequena');
    } else {
      bodyElement.classList.remove('pantalla-grande');
      bodyElement.classList.add('pantalla-pequena');
    }
  }
  