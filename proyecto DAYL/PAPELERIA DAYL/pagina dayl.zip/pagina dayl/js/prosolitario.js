function changeImage(event) {
    var selectedImage = event.target.value;
    var mainImage = document.getElementById("mainImage");
    mainImage.src = selectedImage;
  }
  
  function changeMainImage(element) {
    var mainImage = document.getElementById("mainImage");
    mainImage.src = element.src;
  
    var smallImages = document.getElementsByClassName("small-image");
    for (var i = 0; i < smallImages.length; i++) {
      smallImages[i].classList.remove("selected");
    }
  
    element.classList.add("selected");
  }
  
  let contador = 0;
  const contadorElemento = document.querySelector("#contador");
  
  function aumentar() {
    contador++;
    contadorElemento.textContent = contador;
  }
  
  function disminuir() {
    contador--;
    contadorElemento.textContent = contador;
  }
  
  function showConfirmation() {
    var cantidadInput = document.getElementById("cantidadInput");
    var cantidad = cantidadInput.value;
    alert("¡Formulario enviado correctamente! Cantidad: " + cantidad);
  }
  
  document.getElementById("miDropdown").selectedIndex = -1;
  